import { combineReducers } from 'redux';
import Auth from './auth';

export default combineReducers({ auth: Auth });